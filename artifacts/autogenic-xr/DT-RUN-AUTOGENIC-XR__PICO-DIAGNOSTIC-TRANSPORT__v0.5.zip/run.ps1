$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$PackageId = 'DT-RUN-AUTOGENIC-XR__PICO-DIAGNOSTIC-TRANSPORT__v0.5'
$NestedName = 'DT-RUN-AUTOGENIC-XR__PICO-DIAGNOSTIC__v0.4.zip'
$ExpectedSha = 'faa76bb82fde78063ae270cbec97bfc00237521457d8d2a9e1a67e4fb798d575'
$Nonce = 'AXR-TRANSPORT-V05-20260727-1106-7E5A9C31'
$Started = Get-Date
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$LocalLog = Join-Path $Here '20-LIVE.log'
$LocalResult = Join-Path $Here 'dt-result.json'
$DriveRoot = 'G:\My Drive\AutogenicXR'
$DriveLatest = Join-Path $DriveRoot 'LATEST'
$DriveRuns = 'G:\My Drive\Doubletab\RUNS'
$DriveBootstrap = Join-Path $DriveLatest 'AUTOGENIC-XR__TRANSPORT-BOOTSTRAP__LATEST.json'
$DriveResult = Join-Path $DriveLatest 'AUTOGENIC-XR__TRANSPORT__RESULT__LATEST.json'
$DriveLog = Join-Path $DriveLatest 'AUTOGENIC-XR__TRANSPORT__LOG__LATEST.txt'

function Write-Log([string]$Message) {
    $line = ('{0:o} {1}' -f (Get-Date), $Message)
    Add-Content -LiteralPath $LocalLog -Value $line -Encoding UTF8
}

function Write-JsonAtomic([string]$Path, [object]$Value) {
    $dir = Split-Path -Parent $Path
    if ($dir) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    $tmp = "$Path.tmp-$PID"
    $Value | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $tmp -Encoding UTF8
    Move-Item -LiteralPath $tmp -Destination $Path -Force
}

function Publish([string]$Status, [int]$ExitCode, [hashtable]$Extra) {
    $obj = [ordered]@{
        schema = 'dt-result/v1'
        package_id = $PackageId
        transport_nonce = $Nonce
        status = $Status
        exit_code = $ExitCode
        started_at = $Started.ToString('o')
        finished_at = (Get-Date).ToString('o')
        host = $env:COMPUTERNAME
        user = $env:USERNAME
        source = $Extra.source
        source_sha256 = $Extra.source_sha256
        nested_root = $Extra.nested_root
        nested_exit_code = $Extra.nested_exit_code
        nested_drive_result_fresh = $Extra.nested_drive_result_fresh
        error = $Extra.error
        live_log = $LocalLog
        drive_log = $DriveLog
    }
    Write-JsonAtomic $LocalResult $obj
    if (Test-Path -LiteralPath $DriveLatest) {
        Write-JsonAtomic $DriveResult $obj
        Copy-Item -LiteralPath $LocalLog -Destination $DriveLog -Force
    }
}

try {
    New-Item -ItemType Directory -Force -Path $DriveLatest | Out-Null
    $bootstrap = [ordered]@{
        schema = 'autogenic-xr/transport-bootstrap/v1'
        package_id = $PackageId
        transport_nonce = $Nonce
        started_at = $Started.ToString('o')
        host = $env:COMPUTERNAME
        expected_nested = $NestedName
        expected_sha256 = $ExpectedSha
        stage = 'PRE_ACQUISITION'
    }
    Write-JsonAtomic $DriveBootstrap $bootstrap
    Write-Log "BOOTSTRAP published to $DriveBootstrap"

    $source = Join-Path $DriveRuns $NestedName
    $deadline = (Get-Date).AddMinutes(5)
    while (-not (Test-Path -LiteralPath $source)) {
        if ((Get-Date) -ge $deadline) { throw "Timed out waiting for mounted Drive payload: $source" }
        Write-Log "WAITING_FOR_DRIVE_PAYLOAD $source"
        Start-Sleep -Seconds 5
    }

    $actualSha = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant()
    Write-Log "SOURCE_FOUND path=$source sha256=$actualSha"
    if ($actualSha -ne $ExpectedSha) { throw "Nested ZIP SHA-256 mismatch: expected $ExpectedSha actual $actualSha" }

    $intake = 'E:\Downloads'
    if (-not (Test-Path -LiteralPath $intake)) {
        $intake = Join-Path ([Environment]::GetFolderPath('UserProfile')) 'Downloads'
    }
    $runsRoot = Join-Path $intake '_DT_RUNS'
    New-Item -ItemType Directory -Force -Path $runsRoot | Out-Null
    $runId = '{0}-{1}' -f (Get-Date -Format 'yyyyMMdd-HHmmss'), ([Guid]::NewGuid().ToString('N').Substring(0,10))
    $nestedRoot = Join-Path $runsRoot "DT-RUN-AUTOGENIC-XR__PICO-DIAGNOSTIC__v0.4-$runId"
    New-Item -ItemType Directory -Force -Path $nestedRoot | Out-Null
    Expand-Archive -LiteralPath $source -DestinationPath $nestedRoot -Force
    Write-Log "EXPANDED nested_root=$nestedRoot"

    $entry = Join-Path $nestedRoot 'run.exe'
    if (-not (Test-Path -LiteralPath $entry)) { throw "Nested entrypoint missing: $entry" }
    $previousResultTime = $null
    $nestedDriveResult = Join-Path $DriveLatest 'AUTOGENIC-XR__RESULT__LATEST.json'
    if (Test-Path -LiteralPath $nestedDriveResult) { $previousResultTime = (Get-Item -LiteralPath $nestedDriveResult).LastWriteTimeUtc }

    Write-Log "STARTING nested entrypoint=$entry"
    $proc = Start-Process -FilePath $entry -WorkingDirectory $nestedRoot -PassThru
    $completed = $proc.WaitForExit(180000)
    if (-not $completed) {
        Write-Log "NESTED_TIMEOUT pid=$($proc.Id); leaving process alive for evidence collection"
        $nestedExit = 124
    } else {
        $nestedExit = $proc.ExitCode
        Write-Log "NESTED_EXIT code=$nestedExit"
    }

    $fresh = $false
    if (Test-Path -LiteralPath $nestedDriveResult) {
        $nowTime = (Get-Item -LiteralPath $nestedDriveResult).LastWriteTimeUtc
        $fresh = ($null -eq $previousResultTime) -or ($nowTime -gt $previousResultTime)
    }
    $status = if ($fresh) { 'NESTED_RESULT_RETURNED' } elseif ($nestedExit -eq 0) { 'NESTED_EXITED_WITHOUT_FRESH_RESULT' } else { 'NESTED_FAILED_OR_TIMED_OUT' }
    $exitCode = if ($fresh) { 0 } else { $nestedExit }
    Publish $status $exitCode @{
        source = $source
        source_sha256 = $actualSha
        nested_root = $nestedRoot
        nested_exit_code = $nestedExit
        nested_drive_result_fresh = $fresh
        error = $null
    }
    exit $exitCode
}
catch {
    Write-Log ("FAIL " + $_.Exception.Message)
    Publish 'TRANSPORT_FAILED' 1 @{
        source = $null
        source_sha256 = $null
        nested_root = $null
        nested_exit_code = $null
        nested_drive_result_fresh = $false
        error = $_.Exception.ToString()
    }
    exit 1
}
