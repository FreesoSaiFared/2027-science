Autogenic XR diagnostic transport v0.5

This package is intentionally small. The DT-RUN watcher executes it automatically.
It reads the already-synchronized verified v0.4 diagnostic ZIP from:
  G:\My Drive\Doubletab\RUNS\DT-RUN-AUTOGENIC-XR__PICO-DIAGNOSTIC__v0.4.zip
It verifies SHA-256, extracts under E:\Downloads\_DT_RUNS, runs the nested diagnostic,
and publishes transport bootstrap/result/log files under G:\My Drive\AutogenicXR\LATEST.
No user file shuttling is required.
