$ErrorActionPreference = 'Stop'
$Token = 'MF-ACQ-PROBE-V21-20260727-083033-F01FC749'
$Started = (Get-Date).ToUniversalTime().ToString('o')
$Root = Split-Path -Parent $PSScriptRoot
function Write-JsonAtomic([string]$Path, $Value) {
  $dir = Split-Path -Parent $Path
  if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  $tmp = "$Path.tmp-$PID"
  $Value | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $tmp -Encoding UTF8
  Move-Item -LiteralPath $tmp -Destination $Path -Force
}
function Try-Write([string]$Path, $Value) {
  try { Write-JsonAtomic $Path $Value; return $true } catch { return $false }
}
$bootstrap = [ordered]@{
  schema='doubletab/minefield-acquisition-probe-bootstrap/v2.1'
  token=$Token
  status='BOOTSTRAP_WRITTEN'
  started_at=$Started
  pid=$PID
  working_directory=(Get-Location).Path
  package_root=$Root
}
Write-JsonAtomic (Join-Path $Root 'MINEFIELD-ACQUISITION-PROBE__BOOTSTRAP__LATEST.json') $bootstrap
$targets = @(
  (Join-Path $env:USERPROFILE 'Downloads\_DT_RUNS\MINEFIELD-ACQUISITION-PROBE__BOOTSTRAP__LATEST.json'),
  'G:\My Drive\Doubletab\inbox\MINEFIELD-ACQUISITION-PROBE__BOOTSTRAP__LATEST.json',
  'G:\Doubletab\inbox\MINEFIELD-ACQUISITION-PROBE__BOOTSTRAP__LATEST.json'
)
$bootstrapWrites = @()
foreach ($t in $targets) { $bootstrapWrites += [ordered]@{path=$t;written=(Try-Write $t $bootstrap)} }
$result = [ordered]@{
  schema='doubletab/minefield-acquisition-probe-result/v2.1'
  token=$Token
  ok=$true
  status='ACQUISITION_AND_EXECUTION_PROVEN'
  started_at=$Started
  finished_at=(Get-Date).ToUniversalTime().ToString('o')
  pid=$PID
  powershell_version=$PSVersionTable.PSVersion.ToString()
  os=[Environment]::OSVersion.VersionString
  package_root=$Root
  bootstrap_writes=$bootstrapWrites
  next='Repair WinProxy and activate the stable-ID Minefield extension; artifact acquisition is no longer the boundary.'
}
Write-JsonAtomic (Join-Path $Root 'dt-result.json') $result
$finalTargets = @(
  (Join-Path $env:USERPROFILE 'Downloads\_DT_RUNS\MINEFIELD-ACQUISITION-PROBE__RESULT__LATEST.json'),
  'G:\My Drive\Doubletab\inbox\MINEFIELD-ACQUISITION-PROBE__RESULT__LATEST.json',
  'G:\Doubletab\inbox\MINEFIELD-ACQUISITION-PROBE__RESULT__LATEST.json'
)
foreach ($t in $finalTargets) { [void](Try-Write $t $result) }
exit 0
