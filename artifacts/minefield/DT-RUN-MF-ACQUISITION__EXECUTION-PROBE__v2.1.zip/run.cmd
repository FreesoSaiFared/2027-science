@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\probe.ps1"
exit /b %ERRORLEVEL%
