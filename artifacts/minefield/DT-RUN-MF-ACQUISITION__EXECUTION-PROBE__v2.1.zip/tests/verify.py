from pathlib import Path
import json,hashlib,sys
r=Path(__file__).resolve().parents[1]
m=json.loads((r/'dt-run.json').read_text())
req={'protocol','autolaunch','entrypoint','working_directory','args','admin','keep_open'}
assert req<=set(m) and m['protocol']=='dt-run/v1' and m['autolaunch'] is True
assert (r/m['entrypoint']).is_file()
for line in (r/'MANIFEST.sha256').read_text().splitlines():
    h,rel=line.split('  ',1); assert hashlib.sha256((r/rel).read_bytes()).hexdigest()==h
print('PASS acquisition probe v2.1')
