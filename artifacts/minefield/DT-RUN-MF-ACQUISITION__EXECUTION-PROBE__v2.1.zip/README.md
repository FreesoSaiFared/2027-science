# Minefield Acquisition + Execution Probe v2.1

Token: `MF-ACQ-PROBE-V21-20260727-083033-F01FC749`

This package is deliberately non-mutating. It writes a pre-mutation bootstrap, canonical `dt-result.json`, a local `_DT_RUNS` stable result, and best-effort mounted-Drive receipts. A successful result proves that the current Minefield page actor acquired the artifact and the DT-RUN watcher executed it.
